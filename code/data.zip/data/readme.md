This folder contains the code for loading data.

Files:
load_data.py              Function to load data.
load_data_three_class.py  function to load data for three classifier.
load_data_v16_torch.py    function to load data for version 16.
load_data_v5.py           Legacy Document
load_data_v5_ex1.py       Legacy Document
load_data_v5_ex2.py       Legacy Document
load_data_v5_ex3.py       Legacy Document
load_data_v5_rolling.py   Legacy Document
load_data_v7_ex3.py       Legacy Document
load_data_v7_rolling.py   Legacy Document
load_rnn.py               Legacy Document
